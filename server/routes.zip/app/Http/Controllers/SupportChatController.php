<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SupportChatController extends Controller
{
    //
}
